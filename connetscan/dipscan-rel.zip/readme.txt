Simple port scanner by DiesIrae
	cout << "Usage: dipsccan [OPTION] ... [HOSTNAME/IP] ... [PORT]" << endl << endl;
	cout << "OPTIONS: " << endl;
	cout << "s - Simple scan. One target IP or HOSTNAME(one or more ip) and ONE target PORT" << endl;
	cout << "r - Ranged port scan. One target IP or HOSTNAME(one or more ip), target port FROM and target port TO(range of ports from--->to)" << endl;
	cout << "m - man menu" << endl;
	cout << "m - help menu" << endl << endl;
	cout << "OPTIONS: " << endl;
	cout << "dipscan.exe s www.google.com 443" << endl;
	cout << "dipscan.exe s 192.168.1.1 80" << endl << endl;
	cout << "dipscan.exe r 192.168.1.1 80 160" << endl;
	cout << "dipscan.exe r www.ya.ru 440 500" << endl << endl;
	cout << "dipscan.exe h" << endl;
	cout << "dipscan.exe ?" << endl;

----get it, update it----